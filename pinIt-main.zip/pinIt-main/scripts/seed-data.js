// Seed script to populate the database with sample data

const { MongoClient, ObjectId } = require("mongodb")

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/pinit"

const sampleUsers = [
  {
    _id: new ObjectId(),
    firstName: "Sarah",
    lastName: "Johnson",
    username: "sarahj",
    email: "sarah@example.com",
    password: "$2b$10$hashedpassword1", // In real app, this would be properly hashed
    bio: "Interior designer & home decor enthusiast",
    avatar: "/placeholder.svg?height=128&width=128",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: new ObjectId(),
    firstName: "Mike",
    lastName: "Chen",
    username: "mikec",
    email: "mike@example.com",
    password: "$2b$10$hashedpassword2",
    bio: "Food photographer and recipe creator",
    avatar: "/placeholder.svg?height=128&width=128",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
  {
    _id: new ObjectId(),
    firstName: "Emma",
    lastName: "Davis",
    username: "emmad",
    email: "emma@example.com",
    password: "$2b$10$hashedpassword3",
    bio: "Travel photographer capturing moments",
    avatar: "/placeholder.svg?height=128&width=128",
    createdAt: new Date(),
    updatedAt: new Date(),
  },
]

async function seedDatabase() {
  const client = new MongoClient(MONGODB_URI)

  try {
    await client.connect()
    console.log("Connected to MongoDB for seeding")

    const db = client.db()

    // Insert sample users
    await db.collection("users").insertMany(sampleUsers)
    console.log("Inserted sample users")

    // Create sample boards
    const sampleBoards = [
      {
        _id: new ObjectId(),
        name: "Home Decor",
        description: "Beautiful home decoration ideas",
        userId: sampleUsers[0]._id,
        isPrivate: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        _id: new ObjectId(),
        name: "Recipes",
        description: "Delicious recipes to try",
        userId: sampleUsers[1]._id,
        isPrivate: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        _id: new ObjectId(),
        name: "Travel",
        description: "Amazing places to visit",
        userId: sampleUsers[2]._id,
        isPrivate: false,
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]

    await db.collection("boards").insertMany(sampleBoards)
    console.log("Inserted sample boards")

    // Create sample pins
    const samplePins = [
      {
        _id: new ObjectId(),
        title: "Modern Living Room Design",
        description: "Beautiful minimalist living room with natural lighting",
        imageUrl: "/placeholder.svg?height=300&width=250",
        userId: sampleUsers[0]._id,
        boardId: sampleBoards[0]._id,
        category: "Home Decor",
        tags: ["modern", "minimalist", "living room"],
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        _id: new ObjectId(),
        title: "Healthy Breakfast Bowl",
        description: "Nutritious acai bowl with fresh fruits and granola",
        imageUrl: "/placeholder.svg?height=400&width=250",
        userId: sampleUsers[1]._id,
        boardId: sampleBoards[1]._id,
        category: "Food",
        tags: ["healthy", "breakfast", "acai"],
        createdAt: new Date(),
        updatedAt: new Date(),
      },
      {
        _id: new ObjectId(),
        title: "Sunset Photography",
        description: "Golden hour landscape photography tips",
        imageUrl: "/placeholder.svg?height=350&width=250",
        userId: sampleUsers[2]._id,
        boardId: sampleBoards[2]._id,
        category: "Photography",
        tags: ["sunset", "landscape", "photography"],
        createdAt: new Date(),
        updatedAt: new Date(),
      },
    ]

    await db.collection("pins").insertMany(samplePins)
    console.log("Inserted sample pins")

    console.log("Database seeding completed successfully")
  } catch (error) {
    console.error("Error seeding database:", error)
  } finally {
    await client.close()
  }
}

seedDatabase()
