// MongoDB Database Setup Script
// This script creates the necessary collections and indexes for PinIt

const { MongoClient } = require("mongodb")

const MONGODB_URI = process.env.MONGODB_URI || "mongodb://localhost:27017/pinit"

async function setupDatabase() {
  const client = new MongoClient(MONGODB_URI)

  try {
    await client.connect()
    console.log("Connected to MongoDB")

    const db = client.db()

    // Create collections
    const collections = ["users", "pins", "boards", "comments", "likes", "follows"]

    for (const collectionName of collections) {
      try {
        await db.createCollection(collectionName)
        console.log(`Created collection: ${collectionName}`)
      } catch (error) {
        if (error.code === 48) {
          console.log(`Collection ${collectionName} already exists`)
        } else {
          throw error
        }
      }
    }

    // Create indexes
    await db.collection("users").createIndex({ email: 1 }, { unique: true })
    await db.collection("users").createIndex({ username: 1 }, { unique: true })
    await db.collection("pins").createIndex({ userId: 1 })
    await db.collection("pins").createIndex({ boardId: 1 })
    await db.collection("pins").createIndex({ createdAt: -1 })
    await db.collection("boards").createIndex({ userId: 1 })
    await db.collection("comments").createIndex({ pinId: 1 })
    await db.collection("likes").createIndex({ pinId: 1, userId: 1 }, { unique: true })
    await db.collection("follows").createIndex({ followerId: 1, followingId: 1 }, { unique: true })

    console.log("Database setup completed successfully")
  } catch (error) {
    console.error("Error setting up database:", error)
  } finally {
    await client.close()
  }
}

setupDatabase()
