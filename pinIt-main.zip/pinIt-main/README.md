# PinIt - Pinterest-like Bookmarking Website

A full-stack web application inspired by Pinterest, built with React.js frontend and Express.js backend.

## Features

- **User Authentication**: Secure registration and login with JWT
- **Pin Management**: Upload, organize, and manage image pins
- **Board Organization**: Create custom boards to organize pins
- **Social Features**: Follow users, like pins, and comment
- **Search & Discovery**: Find pins by category, tags, or keywords
- **Responsive Design**: Works seamlessly on desktop and mobile
- **Image Storage**: Cloudinary integration for optimized image handling
- **Real-time Updates**: Dynamic content loading and interactions

## Tech Stack

### Frontend
- **React.js** - UI framework
- **Next.js** - React framework with SSR
- **shadcn/ui** - Modern UI components
- **Tailwind CSS** - Utility-first CSS framework
- **TypeScript** - Type safety

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **MongoDB** - NoSQL database
- **JWT** - Authentication
- **Cloudinary** - Image storage and optimization
- **Multer** - File upload handling

## Getting Started

### Prerequisites
- Node.js (v16 or higher)
- MongoDB (local or Atlas)
- Cloudinary account

### Installation

1. **Clone the repository**
   \`\`\`bash
   git clone <repository-url>
   cd pinit
   \`\`\`

2. **Install frontend dependencies**
   \`\`\`bash
   npm install
   \`\`\`

3. **Install backend dependencies**
   \`\`\`bash
   cd server
   npm install
   \`\`\`

4. **Environment Setup**
   \`\`\`bash
   cp .env.example .env
   \`\`\`
   Fill in your environment variables:
   - MongoDB connection string
   - JWT secret key
   - Cloudinary credentials

5. **Database Setup**
   \`\`\`bash
   npm run setup-db
   npm run seed-db
   \`\`\`

6. **Start the development servers**
   
   Backend:
   \`\`\`bash
   cd server
   npm run dev
   \`\`\`
   
   Frontend:
   \`\`\`bash
   npm run dev
   \`\`\`

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login

### Pins
- `GET /api/pins` - Get all pins (with filtering)
- `POST /api/pins` - Create new pin
- `GET /api/pins/:id` - Get specific pin
- `PUT /api/pins/:id` - Update pin
- `DELETE /api/pins/:id` - Delete pin

### Boards
- `GET /api/boards` - Get user boards
- `POST /api/boards` - Create new board
- `GET /api/boards/:id` - Get specific board
- `PUT /api/boards/:id` - Update board
- `DELETE /api/boards/:id` - Delete board

### Social Features
- `POST /api/users/:id/follow` - Follow user
- `DELETE /api/users/:id/follow` - Unfollow user
- `POST /api/pins/:id/like` - Like pin
- `DELETE /api/pins/:id/like` - Unlike pin
- `GET /api/pins/:id/comments` - Get pin comments
- `POST /api/pins/:id/comments` - Add comment

## Database Schema

### Users Collection
\`\`\`javascript
{
  _id: ObjectId,
  firstName: String,
  lastName: String,
  username: String (unique),
  email: String (unique),
  password: String (hashed),
  bio: String,
  avatar: String,
  createdAt: Date,
  updatedAt: Date
}
\`\`\`

### Pins Collection
\`\`\`javascript
{
  _id: ObjectId,
  title: String,
  description: String,
  imageUrl: String,
  userId: ObjectId (ref: Users),
  boardId: ObjectId (ref: Boards),
  category: String,
  tags: [String],
  createdAt: Date,
  updatedAt: Date
}
\`\`\`

### Boards Collection
\`\`\`javascript
{
  _id: ObjectId,
  name: String,
  description: String,
  userId: ObjectId (ref: Users),
  isPrivate: Boolean,
  createdAt: Date,
  updatedAt: Date
}
\`\`\`

## Deployment

### Frontend (Vercel)
1. Connect your GitHub repository to Vercel
2. Set environment variables in Vercel dashboard
3. Deploy automatically on push to main branch

### Backend (Railway/Render)
1. Create a new service on Railway or Render
2. Connect your GitHub repository
3. Set environment variables:
   - `MONGODB_URI`
   - `JWT_SECRET`
   - `CLOUDINARY_CLOUD_NAME`
   - `CLOUDINARY_API_KEY`
   - `CLOUDINARY_API_SECRET`
4. Deploy from the `server` directory

### Database (MongoDB Atlas)
1. Create a MongoDB Atlas cluster
2. Set up database user and network access
3. Get connection string and add to environment variables

## Project Structure

\`\`\`
pinit/
├── app/                    # Next.js app directory
│   ├── auth/              # Authentication pages
│   ├── profile/           # User profile pages
│   └── page.tsx           # Home page
├── components/            # React components
│   ├── auth/              # Authentication components
│   ├── profile/           # Profile components
│   ├── ui/                # shadcn/ui components
│   ├── pin-card.tsx       # Pin display component
│   ├── pin-grid.tsx       # Pin grid layout
│   ├── search-bar.tsx     # Search functionality
│   └── create-pin-button.tsx
├── server/                # Backend API
│   ├── index.js           # Main server file
│   └── package.json       # Backend dependencies
├── scripts/               # Database scripts
│   ├── setup-database.js  # Database initialization
│   └── seed-data.js       # Sample data insertion
└── README.md
\`\`\`

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- Inspired by Pinterest's user interface and functionality
- Built with modern web technologies and best practices
- Thanks to the open-source community for the amazing tools and libraries

## Support

For support, email support@pinit.com or create an issue in the GitHub repository.
