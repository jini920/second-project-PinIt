import { UserProfile } from "@/components/profile/user-profile"

// Mock user data - replace with actual API call
const mockUser = {
  id: "1",
  name: "Sarah Johnson",
  username: "sarahj",
  bio: "Interior designer & home decor enthusiast. Sharing beautiful spaces and design inspiration.",
  avatar: "/placeholder.svg?height=128&width=128",
  followers: 1234,
  following: 567,
  pins: 89,
}

export default function ProfilePage({ params }: { params: { username: string } }) {
  return (
    <div className="min-h-screen bg-background">
      <UserProfile user={mockUser} />
    </div>
  )
}
