import { Suspense } from "react"
import { PinGrid } from "@/components/pin-grid"
import { SearchBar } from "@/components/search-bar"
import { CategoryFilter } from "@/components/category-filter"
import { CreatePinButton } from "@/components/create-pin-button"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-16 items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-2xl font-bold text-primary">PinIt</h1>
            <SearchBar />
          </div>
          <div className="flex items-center space-x-4">
            <CreatePinButton />
            <div className="h-8 w-8 rounded-full bg-primary" />
          </div>
        </div>
      </header>

      <main className="container py-6">
        <CategoryFilter />
        <Suspense fallback={<div>Loading pins...</div>}>
          <PinGrid />
        </Suspense>
      </main>
    </div>
  )
}
