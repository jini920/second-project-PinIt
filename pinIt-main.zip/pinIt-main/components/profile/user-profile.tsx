"use client"

import { useState } from "react"
import { Share, MoreHorizontal } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface UserProfileProps {
  user: {
    id: string
    name: string
    username: string
    bio: string
    avatar: string
    followers: number
    following: number
    pins: number
  }
}

export function UserProfile({ user }: UserProfileProps) {
  const [isFollowing, setIsFollowing] = useState(false)

  const handleFollow = () => {
    setIsFollowing(!isFollowing)
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      {/* Profile Header */}
      <div className="text-center mb-8">
        <Avatar className="w-32 h-32 mx-auto mb-4">
          <AvatarImage src={user.avatar || "/placeholder.svg"} alt={user.name} />
          <AvatarFallback className="text-2xl">{user.name.charAt(0)}</AvatarFallback>
        </Avatar>

        <h1 className="text-3xl font-bold mb-2">{user.name}</h1>
        <p className="text-muted-foreground mb-1">@{user.username}</p>
        <p className="text-sm max-w-md mx-auto mb-4">{user.bio}</p>

        <div className="flex justify-center gap-6 mb-6">
          <div className="text-center">
            <div className="font-bold text-lg">{user.followers}</div>
            <div className="text-sm text-muted-foreground">Followers</div>
          </div>
          <div className="text-center">
            <div className="font-bold text-lg">{user.following}</div>
            <div className="text-sm text-muted-foreground">Following</div>
          </div>
          <div className="text-center">
            <div className="font-bold text-lg">{user.pins}</div>
            <div className="text-sm text-muted-foreground">Pins</div>
          </div>
        </div>

        <div className="flex justify-center gap-2">
          <Button onClick={handleFollow} variant={isFollowing ? "outline" : "default"}>
            {isFollowing ? "Following" : "Follow"}
          </Button>
          <Button variant="outline">
            <Share className="w-4 h-4 mr-2" />
            Share
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline" size="icon">
                <MoreHorizontal className="w-4 h-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent>
              <DropdownMenuItem>Block user</DropdownMenuItem>
              <DropdownMenuItem>Report</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Profile Tabs */}
      <Tabs defaultValue="pins" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pins">Pins</TabsTrigger>
          <TabsTrigger value="boards">Boards</TabsTrigger>
          <TabsTrigger value="likes">Likes</TabsTrigger>
        </TabsList>

        <TabsContent value="pins" className="mt-6">
          <div className="columns-1 gap-4 sm:columns-2 md:columns-3 lg:columns-4">
            {/* Pin grid would go here */}
            <div className="text-center py-12 text-muted-foreground">No pins yet</div>
          </div>
        </TabsContent>

        <TabsContent value="boards" className="mt-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {/* Board grid would go here */}
            <div className="col-span-full text-center py-12 text-muted-foreground">No boards yet</div>
          </div>
        </TabsContent>

        <TabsContent value="likes" className="mt-6">
          <div className="columns-1 gap-4 sm:columns-2 md:columns-3 lg:columns-4">
            {/* Liked pins grid would go here */}
            <div className="text-center py-12 text-muted-foreground">No liked pins yet</div>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
