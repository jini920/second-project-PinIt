"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"

const categories = ["All", "Fashion", "Home Decor", "Food", "Travel", "Art", "Photography", "DIY", "Beauty", "Fitness"]

export function CategoryFilter() {
  const [selectedCategory, setSelectedCategory] = useState("All")

  return (
    <div className="mb-6 flex flex-wrap gap-2">
      {categories.map((category) => (
        <Button
          key={category}
          variant={selectedCategory === category ? "default" : "outline"}
          size="sm"
          onClick={() => setSelectedCategory(category)}
          className="rounded-full"
        >
          {category}
        </Button>
      ))}
    </div>
  )
}
