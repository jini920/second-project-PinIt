"use client"

import { useState, useEffect } from "react"
import { PinCard } from "./pin-card"
import { Skeleton } from "@/components/ui/skeleton"

interface Pin {
  id: string
  title: string
  description: string
  imageUrl: string
  author: {
    name: string
    avatar: string
  }
  likes: number
  comments: number
  board: string
}

// Mock data - replace with actual API calls
const mockPins: Pin[] = [
  {
    id: "1",
    title: "Modern Living Room Design",
    description: "Beautiful minimalist living room with natural lighting",
    imageUrl: "/placeholder.svg?height=300&width=250",
    author: { name: "Sarah Johnson", avatar: "/placeholder.svg?height=40&width=40" },
    likes: 124,
    comments: 8,
    board: "Home Decor",
  },
  {
    id: "2",
    title: "Healthy Breakfast Bowl",
    description: "Nutritious acai bowl with fresh fruits and granola",
    imageUrl: "/placeholder.svg?height=400&width=250",
    author: { name: "Mike Chen", avatar: "/placeholder.svg?height=40&width=40" },
    likes: 89,
    comments: 12,
    board: "Recipes",
  },
  {
    id: "3",
    title: "Sunset Photography",
    description: "Golden hour landscape photography tips",
    imageUrl: "/placeholder.svg?height=350&width=250",
    author: { name: "Emma Davis", avatar: "/placeholder.svg?height=40&width=40" },
    likes: 256,
    comments: 23,
    board: "Photography",
  },
  {
    id: "4",
    title: "DIY Plant Hanger",
    description: "Easy macrame plant hanger tutorial",
    imageUrl: "/placeholder.svg?height=280&width=250",
    author: { name: "Lisa Park", avatar: "/placeholder.svg?height=40&width=40" },
    likes: 67,
    comments: 5,
    board: "DIY Projects",
  },
  {
    id: "5",
    title: "Fashion Outfit Ideas",
    description: "Casual spring outfit inspiration",
    imageUrl: "/placeholder.svg?height=380&width=250",
    author: { name: "Alex Rivera", avatar: "/placeholder.svg?height=40&width=40" },
    likes: 198,
    comments: 15,
    board: "Fashion",
  },
  {
    id: "6",
    title: "Travel Destination",
    description: "Hidden gems in Santorini, Greece",
    imageUrl: "/placeholder.svg?height=320&width=250",
    author: { name: "Tom Wilson", avatar: "/placeholder.svg?height=40&width=40" },
    likes: 342,
    comments: 28,
    board: "Travel",
  },
]

export function PinGrid() {
  const [pins, setPins] = useState<Pin[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setPins(mockPins)
      setLoading(false)
    }, 1000)
  }, [])

  if (loading) {
    return (
      <div className="columns-1 gap-4 sm:columns-2 md:columns-3 lg:columns-4 xl:columns-5">
        {Array.from({ length: 10 }).map((_, i) => (
          <div key={i} className="mb-4 break-inside-avoid">
            <Skeleton className="h-64 w-full rounded-lg" />
          </div>
        ))}
      </div>
    )
  }

  return (
    <div className="columns-1 gap-4 sm:columns-2 md:columns-3 lg:columns-4 xl:columns-5">
      {pins.map((pin) => (
        <div key={pin.id} className="mb-4 break-inside-avoid">
          <PinCard pin={pin} />
        </div>
      ))}
    </div>
  )
}
