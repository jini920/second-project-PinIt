"use client"

import { useState } from "react"
import Image from "next/image"
import { Heart, MessageCircle, MoreHorizontal, Download } from "lucide-react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Pin {
  id: string
  title: string
  description: string
  imageUrl: string
  author: {
    name: string
    avatar: string
  }
  likes: number
  comments: number
  board: string
}

interface PinCardProps {
  pin: Pin
}

export function PinCard({ pin }: PinCardProps) {
  const [isLiked, setIsLiked] = useState(false)
  const [likes, setLikes] = useState(pin.likes)
  const [isHovered, setIsHovered] = useState(false)

  const handleLike = () => {
    setIsLiked(!isLiked)
    setLikes(isLiked ? likes - 1 : likes + 1)
  }

  return (
    <Card
      className="group relative overflow-hidden border-0 shadow-md transition-all duration-300 hover:shadow-lg"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      <CardContent className="p-0">
        <div className="relative">
          <Image
            src={pin.imageUrl || "/placeholder.svg"}
            alt={pin.title}
            width={250}
            height={300}
            className="h-auto w-full object-cover"
          />

          {/* Overlay with actions */}
          <div
            className={`absolute inset-0 bg-black/20 transition-opacity duration-300 ${isHovered ? "opacity-100" : "opacity-0"}`}
          >
            <div className="absolute right-2 top-2 flex gap-2">
              <Button size="sm" variant="secondary" className="h-8 w-8 rounded-full p-0">
                <Download className="h-4 w-4" />
              </Button>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button size="sm" variant="secondary" className="h-8 w-8 rounded-full p-0">
                    <MoreHorizontal className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem>Save to board</DropdownMenuItem>
                  <DropdownMenuItem>Copy link</DropdownMenuItem>
                  <DropdownMenuItem>Report</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>

        <div className="p-3">
          <h3 className="font-semibold text-sm line-clamp-2 mb-1">{pin.title}</h3>
          <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{pin.description}</p>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Avatar className="h-6 w-6">
                <AvatarImage src={pin.author.avatar || "/placeholder.svg"} alt={pin.author.name} />
                <AvatarFallback>{pin.author.name.charAt(0)}</AvatarFallback>
              </Avatar>
              <span className="text-xs font-medium">{pin.author.name}</span>
            </div>

            <div className="flex items-center gap-2">
              <Button variant="ghost" size="sm" className="h-6 px-2 text-xs" onClick={handleLike}>
                <Heart className={`h-3 w-3 mr-1 ${isLiked ? "fill-red-500 text-red-500" : ""}`} />
                {likes}
              </Button>
              <Button variant="ghost" size="sm" className="h-6 px-2 text-xs">
                <MessageCircle className="h-3 w-3 mr-1" />
                {pin.comments}
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
