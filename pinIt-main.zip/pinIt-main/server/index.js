const express = require("express")
const cors = require("cors")
const dotenv = require("dotenv")
const { MongoClient } = require("mongodb")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")
const multer = require("multer")
const { v2: cloudinary } = require("cloudinary")

dotenv.config()

const app = express()
const PORT = process.env.PORT || 5000

// Middleware
app.use(cors())
app.use(express.json())

// MongoDB connection
let db
MongoClient.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/pinit")
  .then((client) => {
    console.log("Connected to MongoDB")
    db = client.db()
  })
  .catch((error) => console.error("MongoDB connection error:", error))

// Cloudinary configuration
cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
})

// Multer configuration for file uploads
const storage = multer.memoryStorage()
const upload = multer({ storage })

// JWT middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({ error: "Access token required" })
  }

  jwt.verify(token, process.env.JWT_SECRET || "fallback_secret", (err, user) => {
    if (err) {
      return res.status(403).json({ error: "Invalid token" })
    }
    req.user = user
    next()
  })
}

// Auth Routes
app.post("/api/auth/register", async (req, res) => {
  try {
    const { firstName, lastName, username, email, password } = req.body

    // Check if user already exists
    const existingUser = await db.collection("users").findOne({
      $or: [{ email }, { username }],
    })

    if (existingUser) {
      return res.status(400).json({ error: "User already exists" })
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Create user
    const user = {
      firstName,
      lastName,
      username,
      email,
      password: hashedPassword,
      bio: "",
      avatar: "",
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("users").insertOne(user)

    // Generate JWT token
    const token = jwt.sign({ userId: result.insertedId, email }, process.env.JWT_SECRET || "fallback_secret", {
      expiresIn: "7d",
    })

    res.status(201).json({
      message: "User created successfully",
      token,
      user: {
        id: result.insertedId,
        firstName,
        lastName,
        username,
        email,
        bio: user.bio,
        avatar: user.avatar,
      },
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post("/api/auth/login", async (req, res) => {
  try {
    const { email, password } = req.body

    // Find user
    const user = await db.collection("users").findOne({ email })
    if (!user) {
      return res.status(400).json({ error: "Invalid credentials" })
    }

    // Check password
    const isValidPassword = await bcrypt.compare(password, user.password)
    if (!isValidPassword) {
      return res.status(400).json({ error: "Invalid credentials" })
    }

    // Generate JWT token
    const token = jwt.sign({ userId: user._id, email: user.email }, process.env.JWT_SECRET || "fallback_secret", {
      expiresIn: "7d",
    })

    res.json({
      message: "Login successful",
      token,
      user: {
        id: user._id,
        firstName: user.firstName,
        lastName: user.lastName,
        username: user.username,
        email: user.email,
        bio: user.bio,
        avatar: user.avatar,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Pin Routes
app.get("/api/pins", async (req, res) => {
  try {
    const { category, search, limit = 20, skip = 0 } = req.query

    const query = {}

    if (category && category !== "All") {
      query.category = category
    }

    if (search) {
      query.$or = [
        { title: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
        { tags: { $in: [new RegExp(search, "i")] } },
      ]
    }

    const pins = await db
      .collection("pins")
      .aggregate([
        { $match: query },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "author",
          },
        },
        { $unwind: "$author" },
        {
          $project: {
            title: 1,
            description: 1,
            imageUrl: 1,
            category: 1,
            tags: 1,
            createdAt: 1,
            "author.firstName": 1,
            "author.lastName": 1,
            "author.username": 1,
            "author.avatar": 1,
          },
        },
        { $sort: { createdAt: -1 } },
        { $skip: Number.parseInt(skip) },
        { $limit: Number.parseInt(limit) },
      ])
      .toArray()

    res.json(pins)
  } catch (error) {
    console.error("Error fetching pins:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post("/api/pins", authenticateToken, upload.single("image"), async (req, res) => {
  try {
    const { title, description, boardId, category, tags } = req.body

    if (!req.file) {
      return res.status(400).json({ error: "Image is required" })
    }

    // Upload image to Cloudinary
    const uploadResult = await new Promise((resolve, reject) => {
      cloudinary.uploader
        .upload_stream({ resource_type: "image" }, (error, result) => {
          if (error) reject(error)
          else resolve(result)
        })
        .end(req.file.buffer)
    })

    // Create pin
    const pin = {
      title,
      description,
      imageUrl: uploadResult.secure_url,
      userId: req.user.userId,
      boardId,
      category,
      tags: tags ? tags.split(",").map((tag) => tag.trim()) : [],
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("pins").insertOne(pin)

    res.status(201).json({
      message: "Pin created successfully",
      pin: { ...pin, id: result.insertedId },
    })
  } catch (error) {
    console.error("Error creating pin:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Board Routes
app.get("/api/boards", authenticateToken, async (req, res) => {
  try {
    const boards = await db.collection("boards").find({ userId: req.user.userId }).sort({ createdAt: -1 }).toArray()

    res.json(boards)
  } catch (error) {
    console.error("Error fetching boards:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post("/api/boards", authenticateToken, async (req, res) => {
  try {
    const { name, description, isPrivate = false } = req.body

    const board = {
      name,
      description,
      userId: req.user.userId,
      isPrivate,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("boards").insertOne(board)

    res.status(201).json({
      message: "Board created successfully",
      board: { ...board, id: result.insertedId },
    })
  } catch (error) {
    console.error("Error creating board:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// User Routes
app.get("/api/users/:username", async (req, res) => {
  try {
    const { username } = req.params

    const user = await db.collection("users").findOne({ username }, { projection: { password: 0 } })

    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    // Get user stats
    const [pinCount, boardCount, followerCount, followingCount] = await Promise.all([
      db.collection("pins").countDocuments({ userId: user._id }),
      db.collection("boards").countDocuments({ userId: user._id }),
      db.collection("follows").countDocuments({ followingId: user._id }),
      db.collection("follows").countDocuments({ followerId: user._id }),
    ])

    res.json({
      ...user,
      stats: {
        pins: pinCount,
        boards: boardCount,
        followers: followerCount,
        following: followingCount,
      },
    })
  } catch (error) {
    console.error("Error fetching user:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Follow/Unfollow Routes
app.post("/api/users/:userId/follow", authenticateToken, async (req, res) => {
  try {
    const { userId } = req.params
    const followerId = req.user.userId

    if (userId === followerId) {
      return res.status(400).json({ error: "Cannot follow yourself" })
    }

    const existingFollow = await db.collection("follows").findOne({
      followerId,
      followingId: userId,
    })

    if (existingFollow) {
      return res.status(400).json({ error: "Already following this user" })
    }

    await db.collection("follows").insertOne({
      followerId,
      followingId: userId,
      createdAt: new Date(),
    })

    res.json({ message: "User followed successfully" })
  } catch (error) {
    console.error("Error following user:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.delete("/api/users/:userId/follow", authenticateToken, async (req, res) => {
  try {
    const { userId } = req.params
    const followerId = req.user.userId

    await db.collection("follows").deleteOne({
      followerId,
      followingId: userId,
    })

    res.json({ message: "User unfollowed successfully" })
  } catch (error) {
    console.error("Error unfollowing user:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Like/Unlike Routes
app.post("/api/pins/:pinId/like", authenticateToken, async (req, res) => {
  try {
    const { pinId } = req.params
    const userId = req.user.userId

    const existingLike = await db.collection("likes").findOne({
      pinId,
      userId,
    })

    if (existingLike) {
      return res.status(400).json({ error: "Pin already liked" })
    }

    await db.collection("likes").insertOne({
      pinId,
      userId,
      createdAt: new Date(),
    })

    res.json({ message: "Pin liked successfully" })
  } catch (error) {
    console.error("Error liking pin:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.delete("/api/pins/:pinId/like", authenticateToken, async (req, res) => {
  try {
    const { pinId } = req.params
    const userId = req.user.userId

    await db.collection("likes").deleteOne({
      pinId,
      userId,
    })

    res.json({ message: "Pin unliked successfully" })
  } catch (error) {
    console.error("Error unliking pin:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Comment Routes
app.get("/api/pins/:pinId/comments", async (req, res) => {
  try {
    const { pinId } = req.params

    const comments = await db
      .collection("comments")
      .aggregate([
        { $match: { pinId } },
        {
          $lookup: {
            from: "users",
            localField: "userId",
            foreignField: "_id",
            as: "author",
          },
        },
        { $unwind: "$author" },
        {
          $project: {
            text: 1,
            createdAt: 1,
            "author.firstName": 1,
            "author.lastName": 1,
            "author.username": 1,
            "author.avatar": 1,
          },
        },
        { $sort: { createdAt: -1 } },
      ])
      .toArray()

    res.json(comments)
  } catch (error) {
    console.error("Error fetching comments:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post("/api/pins/:pinId/comments", authenticateToken, async (req, res) => {
  try {
    const { pinId } = req.params
    const { text } = req.body

    const comment = {
      pinId,
      userId: req.user.userId,
      text,
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    const result = await db.collection("comments").insertOne(comment)

    res.status(201).json({
      message: "Comment added successfully",
      comment: { ...comment, id: result.insertedId },
    })
  } catch (error) {
    console.error("Error adding comment:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})
